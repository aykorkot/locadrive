<?php
/**
 * 2020  (c)  Egio digital
 *
 * MODULE BlocReassurance
 *
 * @author    Egio digital
 * @copyright Copyright (c) , Egio digital
 * @license   Commercial
 * @version    1.0.0
 */

$sql = array();


/* Information on content EG Banner */
$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'eg_bloc_reassurance` (
        `id_eg_bloc_reassurance` int(10) unsigned NOT NULL AUTO_INCREMENT,  
        `position` int(10) unsigned NOT NULL DEFAULT 0, 
        `active` tinyint(1) unsigned NOT NULL DEFAULT 1,  
        PRIMARY KEY (`id_eg_bloc_reassurance`)
    ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 ;';

/* Localized EG Banner infos */
$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'eg_bloc_reassurance_lang` (
        `id_eg_bloc_reassurance` int(10) unsigned NOT NULL, 
        `id_lang` int(10) unsigned NOT NULL, 
        `id_shop` int(10) unsigned NOT NULL DEFAULT 1,
        `icon` varchar(255) NOT NULL,  
        `title` varchar(128) NOT NULL, 
        `description` longtext,
        PRIMARY KEY (`id_eg_bloc_reassurance`, `id_shop`, `id_lang`)
    ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 ;';

/* Structure table eg_bloc_reassurance shop */
$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'eg_bloc_reassurance_shop` (
	`id_eg_bloc_reassurance` int(10) unsigned NOT NULL, 
	`id_shop` int(10) unsigned NOT NULL ,
	PRIMARY KEY (`id_eg_bloc_reassurance`, `id_shop`), 
	KEY `id_shop` (`id_shop`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8 ;';


foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}
